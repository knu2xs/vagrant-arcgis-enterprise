#!/bin/bash

dir=`dirname $0`
cwd=`cd $dir && pwd`

# Source common utility script
. $cwd/common.sh "$cwd/../locale"

# Exit with N/A on invalid OS's
invalid_os_check


# check file handle limits and process limits
NOFILE_HARD_LIMIT=` ulimit -Hn `
NPROC_HARD_LIMIT=` ulimit -Hu `

# the following is all commented out - yes, a terrible hack to make this work in Vagrant

# if [ $NOFILE_HARD_LIMIT -lt 65535 ] || [ ` ulimit -Sn ` -lt 65535 ] ||
#     [ $NPROC_HARD_LIMIT -lt 25059 ] || [ ` ulimit -Su ` -lt 25059 ]
# then
#   AGS_USER=$CurrentUserName
#   #echo "For ${ProductNameShort} to run properly, the file handle limits for the install"
#   #echo "user are required to be set to 65535 and the number of processes limits set to"
#   #echo "25059. The current file handle limit is $NOFILE_HARD_LIMIT and the number of processes"
#   #echo "limit is $NPROC_HARD_LIMIT."  
#   #echo "To set these limits, you'll need to edit the /etc/security/limits.conf"
#   #echo "file as super user and add the following lines:"
#   #echo
#   #echo "${AGS_USER} soft nofile 65535"
#   #echo "${AGS_USER} hard nofile 65535"
#   #echo "${AGS_USER} soft nproc 25059"
#   #echo "${AGS_USER} hard nproc 25059"
#   #echo
#   #echo "In order for the new values to take effect, you'll need to log out and then log"
#   #echo "back in as the ${AGS_USER} user. To verify, run:"
#   #echo "ulimit -Ha"
#   #echo
#   #echo "For additional details, see the ${ProductName} installation guide."

#   printf_loc "<ERROR_LIMITS_TOO_LOW>" "$ProductNameShort" "$NOFILE_HARD_LIMIT" "$NPROC_HARD_LIMIT" "${AGS_USER}" "${AGS_USER}" "${AGS_USER}" "${AGS_USER}" "${AGS_USER}" "${ProductName}"

#   exit $STATUS_FAILED
# fi

exit $STATUS_PASSED
