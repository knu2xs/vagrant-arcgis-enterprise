#!/bin/bash

dir=`dirname $0`
cwd=`cd $dir && pwd`

# Source common utility script
. $cwd/common.sh "$cwd/../locale"

# Exit with N/A on invalid OS's
invalid_os_check

installDir=`cd $cwd/../../../ && pwd`

PREINSTALL=true

if [ -f "installDir/startserver.sh" ]; then
  PREINSTALL=false
fi

# commenting out the actual test to avoid errors when doing a vagrant provision

# # If this is a preinstall check for root user, otherwise check for root owner of the installDir.
# #
# if $PREINSTALL; then
#   if [ $CurrentUserID -eq 0 ]; then
#     printf_loc "<ERROR_ROOT_INSTALLER>" "$ProductName" "$ProductNameShort" "$ProductName"
#     exit $STATUS_FAILED
#   fi
# else
#   if [ -d "$installDir" ]; then
#     installerID=`stat -c %u $installDir`
#     if [ $installerID -eq 0 ]; then
#       printf_loc "<WARNING_ROOT_INSTALLER>" "$ProductName" "$ProductNameShort"
#       exit $STATUS_WARNING
#     fi
#   fi
# fi

exit $STATUS_PASSED

